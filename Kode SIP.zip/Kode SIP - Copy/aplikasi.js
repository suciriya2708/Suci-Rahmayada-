const API_URL =
  "https://script.google.com/macros/s/AKfycbzSRkLyYQWCWLlp-D_1wDMd1BOa8aR4YR5XNPD8H8nBGwoukhWOF-zX-CxRQvYAdHE/exec";

// Elemen HTML
const btnTambah = document.getElementById("btn-tambah");
const formSection = document.getElementById("form-section");
const formKegiatan = document.getElementById("form-kegiatan");
const btnBatal = document.getElementById("btn-batal");
const daftarKegiatan = document.getElementById("daftar-kegiatan");
const btnSubmit = document.getElementById("btn-submit");
const btnDownloadWord = document.getElementById("btn-download-word");

let dataGlobalKegiatan = [];
const ITEM_PER_PAGE = 5; // Batas jumlah kegiatan per halaman

btnTambah.addEventListener("click", function () {
  formSection.hidden = false;
  btnTambah.hidden = true;
});

btnBatal.addEventListener("click", function () {
  formKegiatan.reset();
  formSection.hidden = true;
  btnTambah.hidden = false;
});

// ==========================================
// PENGIRIMAN DATA (SIMPAN)
// ==========================================
formKegiatan.addEventListener("submit", function (e) {
  e.preventDefault();
  btnSubmit.textContent = "Menyimpan...";
  btnSubmit.disabled = true;

  const dataForm = {
    tanggal: document.getElementById("tanggal").value,
    aktivitas: document.getElementById("aktivitas").value,
    mulai: document.getElementById("mulai").value,
    selesai: document.getElementById("selesai").value,
    action: "save",
  };

  const fotoInput = document.getElementById("foto");
  if (fotoInput.files.length > 0) {
    const file = fotoInput.files[0];
    const reader = new FileReader();

    reader.onload = function (event) {
      const img = new Image();
      img.onload = function () {
        const canvas = document.createElement("canvas");
        const MAX_WIDTH = 600;
        const scaleSize = MAX_WIDTH / img.width;
        canvas.width = MAX_WIDTH;
        canvas.height = img.height * scaleSize;

        const ctx = canvas.getContext("2d");
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);

        const compressedBase64 = canvas.toDataURL("image/jpeg", 0.7);

        dataForm.fotoBase64 = compressedBase64;
        dataForm.namaFoto = file.name;
        dataForm.mimeType = "image/jpeg";

        kirimData(dataForm);
      };
      img.src = event.target.result;
    };
    reader.readAsDataURL(file);
  } else {
    kirimData(dataForm);
  }
});

function kirimData(dataForm) {
  fetch(API_URL, {
    method: "POST",
    headers: { "Content-Type": "text/plain;charset=utf-8" },
    body: JSON.stringify(dataForm),
  })
    .then((response) => response.json())
    .then((result) => {
      btnSubmit.textContent = "Simpan Kegiatan";
      btnSubmit.disabled = false;
      if (result.success) {
        alert("Kegiatan berhasil disimpan!");
        formKegiatan.reset();
        formSection.hidden = true;
        btnTambah.hidden = false;
        muatKegiatan();
      } else {
        alert("Gagal menyimpan: " + result.message);
      }
    })
    .catch((error) => {
      btnSubmit.textContent = "Simpan Kegiatan";
      btnSubmit.disabled = false;
      alert("Terjadi kesalahan jaringan.");
    });
}

// ==========================================
// FUNGSI MENGHAPUS KEGIATAN
// ==========================================
function hapusKegiatan(idKegiatan) {
  if (!confirm("Apakah Anda yakin ingin menghapus kegiatan ini?")) {
    return;
  }

  fetch(API_URL, {
    method: "POST",
    headers: { "Content-Type": "text/plain;charset=utf-8" },
    body: JSON.stringify({ action: "delete", id: idKegiatan }),
  })
    .then((response) => response.json())
    .then((result) => {
      if (result.success) {
        alert("Kegiatan berhasil dihapus!");
        muatKegiatan();
      } else {
        alert("Gagal menghapus: " + result.message);
      }
    })
    .catch((error) => {
      alert("Terjadi kesalahan jaringan.");
    });
}

function formatTanggal(tanggal) {
  if (!tanggal) return "-";

  const bagian = tanggal.split("-");
  if (bagian.length !== 3) return tanggal;

  return `${bagian[2]}/${bagian[1]}/${bagian[0]}`;
}

function buatSel(teks) {
  const td = document.createElement("td");
  td.textContent = teks || "-";
  return td;
}

// Menyimpan halaman yang sedang aktif
let halamanSekarang = 1;

// Menampilkan kegiatan dari terlama ke terbaru

function tampilkanKegiatan(halamanAktif = 1) {
  daftarKegiatan.replaceChildren();

  // Urutkan kegiatan dari tanggal terlama ke terbaru
  const semuaKegiatan = [...dataGlobalKegiatan].sort((a, b) => {
    const tanggalA = (a.tanggal || "").split("T")[0];
    const tanggalB = (b.tanggal || "").split("T")[0];

    if (tanggalA < tanggalB) return -1;
    if (tanggalA > tanggalB) return 1;

    // Tanggal sama: pertahankan urutan dari sumber
    return dataGlobalKegiatan.indexOf(a) - dataGlobalKegiatan.indexOf(b);
  });

  const totalData = semuaKegiatan.length;
  const totalHalaman = Math.max(1, Math.ceil(totalData / ITEM_PER_PAGE));

  halamanSekarang = Math.min(Math.max(1, halamanAktif), totalHalaman);

  // Tampilan tabel khusus web formulir
  const tabel = daftarKegiatan.closest("table");

  if (tabel) {
    tabel.style.borderCollapse = "collapse";
    tabel.style.border = "none";

    tabel.querySelectorAll("th, td").forEach(function (sel) {
      sel.style.setProperty("border", "none", "important");
      sel.style.setProperty("box-shadow", "none", "important");
      sel.style.padding = "10px 12px";
    });

    tabel.querySelectorAll("thead th").forEach(function (sel) {
      sel.style.backgroundColor = "#1a365d";
      sel.style.color = "#ffffff";
      sel.style.textAlign = "left";
    });
  }

  // Jika belum ada kegiatan
  if (totalData === 0) {
    const tr = document.createElement("tr");
    const td = document.createElement("td");

    td.colSpan = 6;
    td.textContent = "Belum ada kegiatan yang tersimpan.";
    td.style.textAlign = "center";

    tr.appendChild(td);
    daftarKegiatan.appendChild(tr);

    buatTombolHalaman(0, 1);
    return;
  }

  // Ambil maksimal lima kegiatan sesuai halaman
  const startIndex = (halamanSekarang - 1) * ITEM_PER_PAGE;

  const dataHalamanIni = semuaKegiatan.slice(
    startIndex,
    startIndex + ITEM_PER_PAGE,
  );

  // Buat baris tabel
  dataHalamanIni.forEach(function (item, index) {
    const tr = document.createElement("tr");

    // Warna baris selang-seling: abu-abu muda dan putih
    tr.style.backgroundColor = index % 2 === 0 ? "#f1f5f9" : "#ffffff";

    // Nomor selalu meningkat dari 1, termasuk lintas halaman
    const nomorUrut = startIndex + index + 1;
    tr.appendChild(buatSel(String(nomorUrut)));

    let tglDisplay = item.tanggal || "-";

    if (tglDisplay.includes("T")) {
      tglDisplay = tglDisplay.split("T")[0];
    }

    tr.appendChild(buatSel(formatTanggal(tglDisplay)));
    tr.appendChild(buatSel(item.aktivitas));
    tr.appendChild(buatSel(item.waktu));

    // Kolom foto
    const tdFoto = document.createElement("td");

    if (item.fotoUrl) {
      const link = document.createElement("a");

      link.href = item.fotoUrl;
      link.target = "_blank";
      link.rel = "noopener noreferrer";
      link.textContent = "Lihat foto";

      tdFoto.appendChild(link);
    } else {
      tdFoto.textContent = "-";
    }

    tr.appendChild(tdFoto);

    // Kolom aksi hapus
    const tdAksi = document.createElement("td");
    const btnHapus = document.createElement("button");

    btnHapus.textContent = "✖";
    btnHapus.style.fontWeight = "bold";
    btnHapus.style.backgroundColor = "#dc3545";
    btnHapus.style.color = "white";
    btnHapus.style.border = "none";
    btnHapus.style.padding = "4px 8px";
    btnHapus.style.borderRadius = "4px";
    btnHapus.style.cursor = "pointer";
    btnHapus.title = "Hapus Kegiatan";

    btnHapus.onclick = function () {
      hapusKegiatan(item.id);
    };

    tdAksi.appendChild(btnHapus);
    tr.appendChild(tdAksi);

    // Hilangkan garis pada semua sel baris ini
    tr.querySelectorAll("td").forEach(function (sel) {
      sel.style.setProperty("border", "none", "important");
      sel.style.setProperty("box-shadow", "none", "important");
    });

    daftarKegiatan.appendChild(tr);
  });

  // Navigasi halaman tetap berfungsi seperti sebelumnya
  buatTombolHalaman(totalData, halamanSekarang);
}

// Membuat navigasi halaman
function buatTombolHalaman(totalData, halamanAktif) {
  let wadahHalaman = document.getElementById("wadah-halaman");

  if (!wadahHalaman) {
    wadahHalaman = document.createElement("div");
    wadahHalaman.id = "wadah-halaman";

    daftarKegiatan.parentElement.insertAdjacentElement(
      "afterend",
      wadahHalaman,
    );
  }

  wadahHalaman.replaceChildren();
  wadahHalaman.style.display = "flex";
  wadahHalaman.style.flexWrap = "wrap";
  wadahHalaman.style.justifyContent = "center";
  wadahHalaman.style.alignItems = "center";
  wadahHalaman.style.gap = "6px";
  wadahHalaman.style.marginTop = "16px";
  wadahHalaman.style.marginBottom = "20px";

  const totalHalaman = Math.ceil(totalData / ITEM_PER_PAGE);

  if (totalHalaman <= 1) return;

  function buatTombol(teks, tujuan, nonaktif = false, aktif = false) {
    const tombol = document.createElement("button");

    tombol.type = "button";
    tombol.textContent = teks;
    tombol.disabled = nonaktif;

    tombol.style.padding = "7px 12px";
    tombol.style.border = "1px solid #1a365d";
    tombol.style.borderRadius = "5px";
    tombol.style.cursor = nonaktif ? "not-allowed" : "pointer";
    tombol.style.fontWeight = aktif ? "bold" : "normal";
    tombol.style.backgroundColor = aktif ? "#1a365d" : "white";
    tombol.style.color = aktif ? "white" : "#1a365d";
    tombol.style.opacity = nonaktif ? "0.45" : "1";

    tombol.addEventListener("click", function () {
      if (!nonaktif) {
        tampilkanKegiatan(tujuan);
      }
    });

    wadahHalaman.appendChild(tombol);
  }

  buatTombol("‹ Sebelumnya", halamanAktif - 1, halamanAktif === 1);

  for (let i = 1; i <= totalHalaman; i++) {
    buatTombol(String(i), i, false, i === halamanAktif);
  }

  buatTombol("Berikutnya ›", halamanAktif + 1, halamanAktif === totalHalaman);

  const info = document.createElement("div");

  const awal = (halamanAktif - 1) * ITEM_PER_PAGE + 1;
  const akhir = Math.min(halamanAktif * ITEM_PER_PAGE, totalData);

  info.textContent =
    `Menampilkan ${awal}–${akhir} dari ${totalData} kegiatan | ` +
    `Halaman ${halamanAktif} dari ${totalHalaman}`;

  info.style.width = "100%";
  info.style.textAlign = "center";
  info.style.fontSize = "13px";
  info.style.marginTop = "8px";
  info.style.color = "#555";

  wadahHalaman.appendChild(info);
}

// ==========================================
// MEMUAT DATA DARI GOOGLE SHEETS
// ==========================================

function muatKegiatan() {
  const callbackName = "kodeLookbookCallback_" + Date.now();

  const script = document.createElement("script");

  const timeout = setTimeout(function () {
    bersihkan();

    console.error("Waktu pemuatan kegiatan habis.");
  }, 15000);

  function bersihkan() {
    clearTimeout(timeout);
    delete window[callbackName];
    script.remove();
  }

  window[callbackName] = function (hasil) {
    bersihkan();

    if (hasil && hasil.success) {
      dataGlobalKegiatan = Array.isArray(hasil.data) ? hasil.data : [];

      // Kembali ke halaman pertama setelah memuat ulang data
      tampilkanKegiatan(1);
    } else {
      console.error(
        "Gagal memuat kegiatan:",
        hasil?.message || "Respons tidak valid.",
      );
    }
  };

  script.onerror = function () {
    bersihkan();
    console.error("Gagal menghubungi Google Sheets.");
  };

  script.src =
    API_URL + "?action=list&callback=" + encodeURIComponent(callbackName);

  document.body.appendChild(script);
}

// ==========================================
// LOGIKA DOWNLOAD KE WORD (KRONOLOGIS / TIDAK DIBALIK)
// ==========================================
function formatTanggalWord(tanggalStr) {
  if (!tanggalStr) return "-";
  let d = tanggalStr.includes("T")
    ? new Date(tanggalStr.split("T")[0])
    : new Date(tanggalStr);
  if (isNaN(d.getTime())) return tanggalStr;
  const hari = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"];
  const bulan = [
    "Januari",
    "Februari",
    "Maret",
    "April",
    "Mei",
    "Juni",
    "Juli",
    "Agustus",
    "September",
    "Oktober",
    "November",
    "Desember",
  ];
  return `${hari[d.getDay()]},<br>${d.getDate()} ${bulan[d.getMonth()]} ${d.getFullYear()}`;
}

function hitungMenit(waktuStr) {
  if (!waktuStr) return 0;
  let normalized = waktuStr.replace("–", "-").replace(" - ", "-");
  if (!normalized.includes("-")) return 0;

  let parts = normalized.split("-");
  let mParts = parts[0].trim().split(":");
  let sParts = parts[1].trim().split(":");
  if (mParts.length < 2 || sParts.length < 2) return 0;

  let totalMulai = parseInt(mParts[0]) * 60 + parseInt(mParts[1]);
  let totalSelesai = parseInt(sParts[0]) * 60 + parseInt(sParts[1]);

  let selisihMenit = totalSelesai - totalMulai;
  return selisihMenit > 0 ? selisihMenit : 0;
}

function formatTotalWaktu(totalMenit) {
  if (totalMenit <= 0) return "-";
  let jam = Math.floor(totalMenit / 60);
  let menit = totalMenit % 60;
  if (jam > 0 && menit === 0) return `${jam} jam`;
  if (jam > 0 && menit > 0) return `${jam} jam ${menit} menit`;
  return `${menit} menit`;
}

btnDownloadWord.addEventListener("click", function () {
  if (!dataGlobalKegiatan || dataGlobalKegiatan.length === 0) {
    alert("Belum ada data untuk diunduh.");
    return;
  }

  let groupedData = {};
  let dateKeys = [];

  // Menggunakan data asli (dataGlobalKegiatan) yang urutannya dari terlama ke terbaru
  dataGlobalKegiatan.forEach((item) => {
    let dateKey = item.tanggal;
    if (dateKey.includes("T")) dateKey = dateKey.split("T")[0];

    if (!groupedData[dateKey]) {
      groupedData[dateKey] = [];
      dateKeys.push(dateKey);
    }
    groupedData[dateKey].push(item);
  });

  let tableHTML = `
    <html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" xmlns="http://www.w3.org/TR/REC-html40">
    <head>
      <meta charset="utf-8">
      <title>Logbook Kegiatan</title>
      <style>
        table { border-collapse: collapse; width: 100%; font-family: 'Times New Roman', Times, serif; }
        th, td { border: 1pt solid black; padding: 8px; vertical-align: middle; }
        th { text-align: center; font-weight: bold; }
      </style>
    </head>
    <body>
    <h2 style="text-align:center; font-family: 'Times New Roman', Times, serif;">Logbook Kegiatan Magang</h2>
    <table>
      <thead>
        <tr>
          <th>No.</th>
          <th>Hari, Tanggal</th>
          <th>Waktu</th>
          <th>Aktivitas/Kegiatan</th>
          <th>Jumlah Waktu<br>Kegiatan<br>(menit/jam)</th>
          <th>Dokumentasi<br>Kegiatan</th>
        </tr>
      </thead>
      <tbody>
  `;

  let nomor = 1;

  dateKeys.forEach((dateKey) => {
    let activities = groupedData[dateKey];
    let rowCount = activities.length;

    let totalMenitHari = 0;
    activities.forEach((act) => {
      totalMenitHari += hitungMenit(act.waktu);
    });

    let durasiHariStr = formatTotalWaktu(totalMenitHari);
    let tanggalStr = formatTanggalWord(dateKey);

    activities.forEach((item, index) => {
      let waktuFormat = (item.waktu || "")
        .replace("–", "-")
        .replace(/:/g, ".")
        .replace("-", " - ");

      let fotoHTML = "-";
      if (item.fotoBase64) {
        fotoHTML = `<img src="${item.fotoBase64}" alt="Dokumentasi" height="113">`;
      }

      tableHTML += `<tr>`;

      if (index === 0) {
        tableHTML += `<td rowspan="${rowCount}" style="text-align:center;">${nomor}</td>`;
        tableHTML += `<td rowspan="${rowCount}">${tanggalStr}</td>`;
      }

      tableHTML += `<td style="text-align:center;">${waktuFormat}</td>`;
      tableHTML += `<td>${item.aktivitas}</td>`;

      if (index === 0) {
        tableHTML += `<td rowspan="${rowCount}" style="text-align:center;">${durasiHariStr}</td>`;
      }

      tableHTML += `<td style="text-align:center; padding: 4px;">${fotoHTML}</td>`;

      tableHTML += `</tr>`;
    });

    nomor++;
  });

  tableHTML += `</tbody></table></body></html>`;

  const blob = new Blob(["\ufeff", tableHTML], { type: "application/msword" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = "Logbook_Magang.doc";

  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
});

// Muat data saat pertama kali halaman dibuka
muatKegiatan();
